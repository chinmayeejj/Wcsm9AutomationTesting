package dataProviders;

public class Simple 
{
	public static void main(String[] args) 
	{
		String [] [] data=new String[5] [5];
		data[0] [0]="admin";
		data[1][0]="manager";
		System.out.println(data[0] [0]);
		
	}

}
