package pageObjectModel;

public interface IautoConstant {
	String EXCEL_PATH="./src/main/resources/ActiTimeTestData1.xlsx";
	String PROP_PATH="./src/main/resources/config.properties";
	
	String VALIDCREDS_SHEET="validcreds";
	String INVALIDCREDS_SHEET="invalidcreds";
	
	String CUSTOMER_PROJECT_SHEET="project&customer";
	String MANAGER_CREDS_SHEET="managercreds";
	


}
