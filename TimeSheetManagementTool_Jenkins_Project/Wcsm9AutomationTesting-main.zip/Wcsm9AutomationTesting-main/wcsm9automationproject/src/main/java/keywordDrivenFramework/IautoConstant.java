package keywordDrivenFramework;

public interface IautoConstant 
{
	String EXCEL_PATH="./src/main/resources/ActiTimeTestData1.xlsx";
	String PROP_PATH="./src/main/resources/config.properties";
	String VALIDCREDS_SHEET="validcreds";
	String INVALIDCREDS_SHEET="invalidcreds";
}
