package genericPackage;

public interface IautoConstant 
{
	String EXCEL_PATH="./src/test/resources/ActiTimeTestData1.xlsx";
	String PROP_PATH="./src/main/resources/config.properties";
    String PROP_PATH1="./src/test/resources/config1.properties";
    
  
    String SCREENSHOT_PATH="./screenshots/";
    
    String VALIDSHEET_NAME="validcreds";
    String INVALIDSHEET_NAME="invalidcreds";
    String MANAGERSHEET_NAME="managercreds";
    String CUST_PROSHEET_NAME="project&customer";
	

}
