package testPackage;

import org.testng.annotations.Test;

public class InvalidLoginTestCase {
  @Test
  public void f() {
  }
}
